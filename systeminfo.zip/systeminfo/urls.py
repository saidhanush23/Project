from django.urls import path
from . import views

urlpatterns = [
    path('', views.htop, name='htop'),  # Add this line for the root URL
    path('htop/', views.htop, name='htop'),
]
