from django.http import HttpResponse
from datetime import datetime
import os
import subprocess

def htop(request):
    # Replace this with your full name
    name = "Sai Dhanush Gavini"

    # Get the system username
    username = os.getlogin()

    # Get the server time in IST
    ist_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S IST')

    # Run the 'top' command and capture its output
    top_output = subprocess.getoutput('top -b -n 1')

    # Format the output for HTML display
    response_html = f"""
    <h1>System Info Page</h1>
    <p><strong>Name:</strong> {name}</p>
    <p><strong>Username:</strong> {username}</p>
    <p><strong>Server Time (IST):</strong> {ist_time}</p>
    <h2>Top Command Output:</h2>
    <pre>{top_output}</pre>
    """

    return HttpResponse(response_html)
